<?php /* Template: migrated approved design */ ?>
<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Культура Неона — мастерская света</title><style>
@import url('https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Nunito:wght@400;500;600;700;800;900&family=Nunito+Sans:wght@400;500;600;700;800;900&display=swap');
:root{--ink:#241c18;--orange:#d85a1c;--cream:#fff4e8}*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:radial-gradient(ellipse at 45% 35%,#fff9f2 0%,#fff1e3 85%);font-family:Manrope,Arial,sans-serif;color:var(--ink)}button,a{font:inherit}button{cursor:pointer}.site-header{height:57px;border-bottom:1px solid #e9d4c3;background:#fff7eecc;display:flex;align-items:center;justify-content:space-between;padding:0 3.5%;gap:18px;position:relative;z-index:5}.logo{display:flex;align-items:center;gap:10px;font-size:20px;font-weight:800;letter-spacing:-.7px;white-space:nowrap}.logo-mark{width:30px;height:30px;position:relative;display:inline-block}.logo-mark i{position:absolute;width:18px;height:3px;border-radius:4px;background:#e87523;left:8px;top:13px;transform-origin:0 50%}.logo-mark i:nth-child(1){transform:rotate(-45deg)}.logo-mark i:nth-child(2){transform:rotate(0deg)}.logo-mark i:nth-child(3){transform:rotate(45deg)}.logo-mark:after{content:'';position:absolute;width:7px;height:3px;background:#e87523;top:3px;left:3px;transform:rotate(15deg)}nav{display:flex;align-items:center;gap:24px;height:100%}nav a{text-decoration:none;color:#201b19;font-size:12px;white-space:nowrap;height:100%;display:flex;align-items:center;position:relative}nav a.active{font-weight:800}nav a.active:after{content:'';height:2px;background:var(--orange);position:absolute;bottom:11px;left:0;right:0}.header-icons{display:flex;align-items:center;gap:19px}.icon-btn{background:transparent;border:0;padding:0;display:flex;align-items:center;justify-content:center;color:#201b19;position:relative}.icon-btn svg{width:23px;height:23px;stroke-width:1.6}.cart-count{position:absolute;right:-7px;top:-6px;background:#e96a22;color:white;border-radius:50%;font-size:10px;min-width:15px;height:15px;display:grid;place-items:center}.hero{width:100%;max-width:none;min-height:450px;margin:0;position:relative;overflow:hidden;padding:29px 28% 15px;text-align:center}.left-photo,.right-photo{position:absolute;top:0;background-repeat:no-repeat;background-position:center;background-size:cover;height:400px;pointer-events:none}.left-photo{left:0;width:min(30%,307px);background-image:url(https://ravezox.github.io/kultura-neona/coffee-neon.webp);clip-path:url(#coffee-blob)}.right-photo{right:0;width:min(32%,328px);height:409px;background-image:url(https://ravezox.github.io/kultura-neona/lion-nursery.webp);clip-path:url(#lion-blob)}.eyebrow{display:inline-block;background:#f8ddc7;border:1px solid #f3d4bc;border-radius:30px;padding:7px 21px;font-size:12px;font-weight:800;letter-spacing:1.8px;white-space:nowrap}.hero h1{font-size:clamp(35px,4.7vw,62px);letter-spacing:-2.6px;line-height:1.02;font-weight:800;margin:29px -35px 25px;position:relative}.character-accent{position:relative;display:inline-block;white-space:nowrap}.character-underline{position:absolute;left:8%;bottom:-.20em;width:92%;height:.27em;color:#ed6019;overflow:visible;pointer-events:none}.character-period{position:relative;display:inline-block;vertical-align:baseline;line-height:inherit}.character-period-text{font:inherit;letter-spacing:0}.character-rays{position:absolute;width:.75em;height:.79em;left:.32em;top:-.18em;color:#ed6019;overflow:visible;pointer-events:none}.hero p{font-size:clamp(17px,2vw,23px);line-height:1.3;margin:29px -35px 27px}.hero-actions{display:flex;justify-content:center;gap:12px;white-space:nowrap}.cta{border-radius:100px;padding:14px 19px;border:1.5px solid #bd5b2e;display:inline-flex;align-items:center;justify-content:center;gap:9px;text-decoration:none;font-weight:700;font-size:13px;transition:transform .2s,box-shadow .2s}.cta:hover{transform:translateY(-2px);box-shadow:0 7px 20px #b9612530}.cta.primary{background:linear-gradient(120deg,#c64b14,#e77b2c);color:white}.cta.secondary{background:#fffaf4;color:#281b16}.cta svg{width:20px;height:20px;flex:none}.spark{position:absolute;color:#dc5a1b;font-size:33px;font-weight:700}.spark.one{left:29%;top:36px;transform:rotate(28deg)}.spark.two{right:28%;top:140px;transform:rotate(-18deg)}.benefits{max-width:850px;margin:14px auto 0;display:grid;grid-template-columns:repeat(3,1fr);gap:0;align-items:center}.benefit{display:flex;align-items:center;justify-content:center;gap:14px;text-align:left;font-size:13px;font-weight:600;line-height:1.3;min-height:45px}.benefit:not(:last-child){border-right:1px solid #d8b8a0}.benefit svg{width:36px;height:36px;stroke:#d65d22;stroke-width:1.5;fill:none;flex:none}.mobile-menu{display:none}.notice{display:none;position:fixed;bottom:20px;left:50%;transform:translateX(-50%);background:#30251f;color:#fff;padding:12px 18px;border-radius:12px;z-index:20;font-size:13px;box-shadow:0 12px 35px #0002}.notice.show{display:block}.ornament{position:absolute;bottom:3px;width:22%;height:40px;border-top:1.5px solid #cf672f;border-radius:50%;opacity:.9}.ornament.left{left:-2%;transform:rotate(-6deg)}.ornament.right{right:-2%;transform:rotate(-10deg)}
@media(max-width:1100px){nav{gap:13px}.site-header{padding:0 2%}.logo{font-size:17px}.header-icons{gap:12px}.hero{padding-left:29%;padding-right:29%}.hero h1{font-size:clamp(34px,4.6vw,52px)}.cta{padding:12px 14px;font-size:12px}}
@media(max-width:760px){.site-header{height:64px;padding:0 17px}.logo{font-size:18px}.mobile-menu{display:flex}.header-icons{gap:15px}.header-icons .account{display:none}nav{display:none;position:absolute;top:64px;left:0;right:0;background:#fff7ee;box-shadow:0 12px 22px #55331c20;padding:14px 20px;height:auto;flex-direction:column;align-items:flex-start;gap:0}nav.open{display:flex}nav a{height:42px;font-size:14px}nav a.active:after{bottom:3px}.hero{padding:24px 18px 28px;display:flex;flex-direction:column;align-items:center;min-height:unset;overflow:hidden}.left-photo,.right-photo{position:relative;top:auto;left:auto;right:auto;width:46%;height:auto;aspect-ratio:307/400;flex:none}.left-photo{align-self:flex-start;order:3;margin-top:25px}.right-photo{align-self:flex-end;order:4;margin-top:-49%;aspect-ratio:328/409}.eyebrow{font-size:10px;letter-spacing:1px;order:0}.hero h1{order:1;font-size:clamp(39px,9vw,65px);margin:25px 0 0;letter-spacing:-2px;max-width:650px}.hero p{order:2;margin:25px 0 15px;font-size:18px}.hero-actions{order:5;margin-top:20px;flex-wrap:wrap}.benefits{order:6;grid-template-columns:1fr;gap:12px;margin-top:35px;width:100%;max-width:330px}.benefit{justify-content:flex-start;border:0!important}.spark,.ornament{display:none}}
@media(max-width:390px){.logo{font-size:15px}.header-icons{gap:9px}.cta{font-size:12px}}

/* Typography-only refinement to match the approved mockup. */
@import url('https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Nunito+Sans:wght@400;500;600;700;800;900&family=Nunito:wght@900&display=swap');
.logo{font-family:'Nunito Sans',Manrope,Arial,sans-serif;font-weight:900;letter-spacing:-.85px}
.eyebrow{font-family:'Nunito Sans',Manrope,Arial,sans-serif;font-weight:900;letter-spacing:1.35px}
.hero h1{font-family:'Nunito','Nunito Sans',Manrope,Arial,sans-serif;font-weight:900;letter-spacing:-2.6px}
.hero p{font-family:'Nunito Sans',Manrope,Arial,sans-serif;font-weight:600;letter-spacing:-.35px}

/* Decorative waves and directions, following the supplied prototype. */
.ornament{display:none}
.hero-wave{position:absolute;bottom:-4px;width:26%;height:95px;pointer-events:none;z-index:1;overflow:visible}
.hero-wave.left{left:0}.hero-wave.right{right:0}.hero-wave path{fill:none;stroke:#e85c22;stroke-width:1.5;stroke-linecap:round}
.directions{max-width:1190px;margin:0 auto;padding:8px 26px 48px;position:relative}
.directions h2{text-align:center;font-family:'Nunito','Nunito Sans',sans-serif;font-weight:900;font-size:34px;letter-spacing:-.9px;margin:12px 0 20px;line-height:1.2}
.directions h2:before{content:'〃';display:inline-block;color:#e86620;font-size:42px;vertical-align:middle;transform:rotate(-28deg);margin-right:19px;font-family:Arial,sans-serif;font-weight:700}
.directions-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.direction-card{height:273px;border-radius:24px;position:relative;overflow:hidden;background-size:cover;background-position:center}
.direction-card.neon{background-image:linear-gradient(90deg,transparent 0%,#24150d22 44%,#24150d55 100%),url('https://ravezox.github.io/kultura-neona/baby-barber-card.svg');color:white}
.direction-card.lamps{background-image:url('https://ravezox.github.io/kultura-neona/owl-real-card.webp');background-position:23% 45%;color:#241b16}
.direction-copy{position:absolute;top:28px;right:18px;width:44%;text-align:left}
.direction-card.lamps .direction-copy{right:15px;width:42%}
.direction-copy h3{font-family:'Nunito Sans',Manrope,sans-serif;font-size:29px;font-weight:900;letter-spacing:-1.1px;line-height:1.05;margin:0 0 17px}
.direction-copy p{font-size:16px;line-height:1.35;margin:0 0 19px;font-weight:500}
.direction-copy .direction-link{display:inline-flex;align-items:center;gap:16px;background:linear-gradient(100deg,#e46b23,#d75a18);border:1px solid #f5a06c;color:#fff;text-decoration:none;border-radius:28px;padding:12px 22px;font-size:15px;font-weight:800;white-space:nowrap}
.direction-copy .direction-link span{font-size:25px;line-height:16px;font-weight:400}
@media(max-width:760px){.hero-wave{display:none}.directions{padding:18px 16px 35px}.directions h2{font-size:29px}.directions-grid{grid-template-columns:1fr}.direction-card{height:260px}.direction-copy h3{font-size:24px}.direction-copy p{font-size:14px}.direction-copy{width:45%;right:12px;top:25px}.direction-card.lamps .direction-copy{width:44%;right:12px}}
@media(max-width:390px){.direction-copy h3{font-size:22px}.direction-copy .direction-link{padding:10px 14px;font-size:13px}}

/* Approved hero is untouched; place contour echoes below the photos. */
@media(min-width:761px){.hero{min-height:520px;overflow:visible}.hero-wave{top:414px;bottom:auto;height:92px;width:29%;z-index:0}.hero-wave.left{left:0}.hero-wave.right{right:0}.directions{padding-top:0}}
.hero-wave path{stroke-width:1.65}
.directions h2{font-family:'Nunito','Nunito Sans',Manrope,sans-serif;font-weight:900;letter-spacing:-1.3px;font-size:37px}
.direction-copy h3{font-family:'Nunito','Nunito Sans',Manrope,sans-serif;font-weight:900;letter-spacing:-1.15px}
.direction-copy p,.direction-copy .direction-link{font-family:'Nunito Sans',Manrope,sans-serif}
@media(max-width:760px){.directions h2{font-size:30px}.direction-copy h3{font-size:25px}}

/* Only the Our Directions section: approved rounded lettering and three orange strokes. */
.directions h2{display:flex;align-items:center;justify-content:center;gap:15px;font-family:'Nunito',sans-serif!important;font-weight:900!important;letter-spacing:-1.8px!important;line-height:1.12!important}
.directions h2:before{content:none!important;display:none!important}
.directions-sparks{width:42px;height:42px;flex:none;overflow:visible}
.directions h2 span{font-family:'Nunito',sans-serif;font-weight:900}
.direction-copy h3{font-family:'Nunito',sans-serif!important;font-weight:900!important;letter-spacing:-1.3px!important;line-height:1.06}
@media(max-width:760px){.directions h2{gap:8px;letter-spacing:-1.1px!important}.directions-sparks{width:32px;height:32px}}

/* Final visual polish restricted to the Our Directions cards. */
.directions-grid{gap:12px}
.direction-card{isolation:isolate;box-shadow:0 1px 0 #66391a0b}
.direction-card.neon{background-position:left center;background-size:cover}
.direction-card.lamps{background-position:left center;background-size:cover;background-color:#dfb18d}
.direction-card.lamps:after{content:'';position:absolute;inset:0;z-index:0;pointer-events:none;background:linear-gradient(90deg,transparent 0%,transparent 43%,#e6bb9c33 56%,#eac5a9a8 70%,#eac5a9e6 100%)}
.direction-card .direction-copy{z-index:1}
.direction-copy h3{font-family:'Nunito',sans-serif!important;font-weight:900!important;font-size:30px;letter-spacing:-1.3px!important;line-height:1.05}
.direction-copy p{font-family:'Nunito Sans',sans-serif;font-weight:600;letter-spacing:-.25px}
.direction-link{transition:transform .18s,filter .18s}
.direction-link:hover{transform:translateY(-2px);filter:brightness(1.08)}
@media(max-width:760px){.direction-copy h3{font-size:25px}}

/* Real owl photo: preserve owl's actual geometry and keep copy legible. */
.direction-card.lamps{background-position:21% 46%;background-size:cover}
.direction-card.lamps:after{background:linear-gradient(90deg,transparent 0%,#e8c4a000 35%,#e8c4a0b0 55%,#e8c4a0f2 73%,#e8c4a0fa 100%)}
@media(max-width:760px){.direction-card.lamps{background-position:25% center}}

/* Approved two-card composition: dark neon with foliage; beige real owl, correctly scaled. */
.directions .direction-card{height:273px;border-radius:25px;overflow:hidden}
.directions .direction-card.neon{background-image:linear-gradient(90deg,#170e0b00 0%,#1d100c0a 37%,#281a17c9 59%,#291a16e6 100%),url('https://ravezox.github.io/kultura-neona/baby-barber-card.svg');background-size:cover;background-position:left center}
.directions .direction-card.lamps{background:#e9bf9d;background-image:radial-gradient(ellipse at 28% 45%,#f7d6a6 0%,#edc29d 55%,#e8b995 100%);background-size:cover}
.directions .direction-card.lamps:before{content:'';position:absolute;z-index:0;inset:0 auto 0 0;width:58%;background-image:url('https://ravezox.github.io/kultura-neona/owl-real-card.webp');background-repeat:no-repeat;background-position:50% 49%;background-size:auto 390px;mask-image:linear-gradient(90deg,#000 0%,#000 70%,transparent 100%);-webkit-mask-image:linear-gradient(90deg,#000 0%,#000 70%,transparent 100%)}
.directions .direction-card.lamps:after{content:'';position:absolute;inset:0;z-index:0;pointer-events:none;background:linear-gradient(90deg,transparent 0%,transparent 48%,#e9bf9d55 57%,#e9bf9d00 76%)}
.directions .direction-copy{right:17px;top:29px;width:43%;z-index:2}
.directions .direction-card.lamps .direction-copy{right:15px;width:43%}
.directions .direction-copy h3{font-family:'Nunito',sans-serif!important;font-weight:900!important;font-size:29px;line-height:1.04;letter-spacing:-1.25px!important;margin-bottom:18px}
.directions .direction-copy p{font-family:'Nunito Sans',sans-serif;font-weight:600;font-size:15px;line-height:1.35;margin-bottom:19px}
.directions .direction-card.neon .direction-copy{color:#fff}
.directions .direction-card.lamps .direction-copy{color:#241a15}
@media(max-width:760px){.directions .direction-card{height:260px}.directions .direction-card.lamps:before{background-size:auto 365px}.directions .direction-copy h3{font-size:24px}.directions .direction-copy p{font-size:14px}.directions .direction-copy{width:44%;right:12px}.directions .direction-card.lamps .direction-copy{width:44%;right:12px}}
@media(max-width:390px){.directions .direction-card.lamps:before{background-size:auto 330px}.directions .direction-copy h3{font-size:22px}}

/* Screenshot-matched directions layout only. Hero remains unchanged. */
.directions{max-width:1440px;padding:8px 3.3% 50px}
.directions h2{margin:8px 0 26px;font-family:'Nunito',sans-serif!important;font-weight:900!important;font-size:clamp(30px,3.1vw,43px);letter-spacing:-1.4px!important}
.directions-grid{gap:12px;grid-template-columns:minmax(0,1fr) minmax(0,1fr)}
.directions .direction-card{height:auto;aspect-ratio:2.08/1;border-radius:28px}
.directions .direction-card.neon{background-color:#291a15;background-image:linear-gradient(90deg,#21130d00 0%,#26171000 40%,#281913d9 56%,#281913f5 100%),url('https://ravezox.github.io/kultura-neona/baby-barber-card.svg');background-size:cover;background-position:0 center}
.directions .direction-card.lamps{background:#edc39f;background-image:radial-gradient(ellipse at 28% 46%,#ffe4b4 0%,#f5d2aa 35%,#eec29d 76%,#e8b78f 100%)}
.directions .direction-card.lamps:before{width:52%;height:100%;inset:0 auto 0 0;background-image:url('https://ravezox.github.io/kultura-neona/owl-real-card.webp');background-repeat:no-repeat;background-position:50% 49%;background-size:auto 112%;-webkit-mask-image:linear-gradient(90deg,#000 0%,#000 74%,transparent 100%);mask-image:linear-gradient(90deg,#000 0%,#000 74%,transparent 100%)}
.directions .direction-card.lamps:after{background:linear-gradient(90deg,transparent 0%,transparent 44%,#efc49f88 52%,#efc49f00 68%)}
.directions .direction-copy{top:11%;right:4%;width:43%;display:flex;flex-direction:column;align-items:flex-start;height:78%}
.directions .direction-card.lamps .direction-copy{right:4%;width:40%}
.directions .direction-copy h3{font-family:'Nunito',sans-serif!important;font-size:clamp(20px,2.45vw,36px);line-height:1.03!important;letter-spacing:-1.25px!important;margin:0 0 7%}
.directions .direction-copy p{font-family:'Nunito Sans',sans-serif;font-weight:600;font-size:clamp(12px,1.37vw,19px);line-height:1.25;margin:0}
.directions .direction-copy .direction-link{margin-top:auto;padding:12px 21px;font-family:'Nunito Sans',sans-serif;font-size:clamp(13px,1.2vw,17px);border-radius:100px}
@media(max-width:760px){.directions{padding:18px 16px 36px}.directions-grid{grid-template-columns:1fr}.directions .direction-card{aspect-ratio:1.92/1;min-height:235px}.directions .direction-copy h3{font-size:clamp(20px,5.1vw,30px)}.directions .direction-copy p{font-size:clamp(12px,3.2vw,16px)}.directions .direction-card.lamps:before{background-size:auto 112%}}
@media(max-width:390px){.directions .direction-copy .direction-link{padding:9px 13px;font-size:12px}.directions .direction-copy{right:3%;width:45%}.directions .direction-card.lamps .direction-copy{right:3%;width:43%}}

/* Reference-faithful, independent responsive direction cards. */
.directions .direction-card{aspect-ratio:2.08/1;min-height:270px;border-radius:27px}
.directions .direction-card.neon{background-image:linear-gradient(90deg,transparent 0%,transparent 43%,#291a17b0 53%,#291a17e8 68%,#291a17f0 100%),url('https://ravezox.github.io/kultura-neona/baby-barber-card.svg');background-position:center;background-size:cover}
.directions .direction-card.lamps{background:radial-gradient(ellipse at 26% 44%,#ffe6ba 0%,#f6d4ad 35%,#edc19b 75%,#e7b790 100%)}
.directions .direction-card.lamps:before{content:'';position:absolute;inset:0 auto 0 0;width:55%;height:100%;background:url('https://ravezox.github.io/kultura-neona/owl-real-card.webp') center 50% / auto 112% no-repeat;-webkit-mask-image:linear-gradient(90deg,#000 0%,#000 78%,transparent 100%);mask-image:linear-gradient(90deg,#000 0%,#000 78%,transparent 100%)}
.directions .direction-card.lamps:after{background:linear-gradient(90deg,transparent 0%,transparent 47%,#edc19b44 57%,transparent 70%)}
.directions .direction-copy{top:11%;right:4%;width:43%;height:79%;z-index:2;display:flex;flex-direction:column}
.directions .direction-card.lamps .direction-copy{right:4%;width:40%}
.directions .direction-copy h3{font-family:'Nunito',sans-serif!important;font-size:clamp(22px,2.5vw,35px)!important;font-weight:900!important;letter-spacing:-1.35px!important;line-height:1.04!important;margin:0 0 8%}
.directions .direction-copy p{font-family:'Nunito Sans',sans-serif;font-size:clamp(12px,1.37vw,19px);font-weight:600;line-height:1.27}
.directions .direction-copy .direction-link{appearance:none;border:1px solid #f9a061;align-self:flex-start;margin-top:auto;display:inline-flex;align-items:center;justify-content:center;gap:14px;background:linear-gradient(110deg,#e46b20,#f16d13);color:#fff;border-radius:999px;font-family:'Nunito',sans-serif;font-weight:900;font-size:clamp(13px,1.35vw,18px);padding:12px 22px;cursor:pointer}
.directions .direction-link:focus-visible{outline:3px solid #fba44d;outline-offset:3px}
.direction-dialog{border:0;border-radius:25px;padding:0;max-width:min(540px,calc(100vw - 32px));width:100%;background:#fff4e9;color:#241c18;box-shadow:0 20px 90px #1e100b66}
.direction-dialog::backdrop{background:#1c120db8;backdrop-filter:blur(3px)}
.direction-dialog-inner{padding:27px 30px 30px}
.direction-dialog h3{font-family:'Nunito',sans-serif;font-size:28px;line-height:1.12;margin:0 40px 14px 0}
.direction-dialog p{font-family:'Nunito Sans',sans-serif;font-size:16px;line-height:1.5;margin:0 0 18px}
.direction-dialog img{width:100%;max-height:230px;object-fit:contain;border-radius:15px;background:#eac5a6;margin-bottom:16px}
.direction-dialog-close{position:absolute;top:15px;right:16px;border:0;border-radius:50%;background:#f2dcc8;width:35px;height:35px;font-size:25px;line-height:1;cursor:pointer}
@media(max-width:760px){.directions .direction-card{min-height:235px;aspect-ratio:1.95/1}.directions .direction-copy h3{font-size:clamp(20px,5vw,29px)!important}.directions .direction-copy p{font-size:clamp(12px,3vw,16px)}.directions .direction-copy .direction-link{font-size:14px;padding:10px 15px}.directions .direction-card.lamps:before{background-size:auto 112%}}
@media(max-width:390px){.directions .direction-card{min-height:225px}.directions .direction-copy h3{font-size:21px!important}.directions .direction-copy .direction-link{font-size:12px;padding:9px 12px}}

/* Reference correction — scoped exclusively to Our Directions. */
.directions{max-width:1440px;padding:8px 3.3% 48px}
.directions-grid{gap:12px}
.directions .direction-card{height:auto;min-height:0;aspect-ratio:2.08/1;border-radius:28px;position:relative;isolation:isolate;overflow:hidden}
.directions .direction-card.neon{background:#2c1a14;background-image:linear-gradient(90deg,transparent 0%,transparent 47%,#2b1b16b8 57%,#2b1b16f0 76%),url('https://ravezox.github.io/kultura-neona/baby-barber-card.svg');background-repeat:no-repeat;background-size:100% 100%,65% 100%;background-position:center,left center}
.directions .direction-card.lamps{background:radial-gradient(ellipse at 26% 48%,#ffe8b7 0%,#f6d2aa 43%,#edc29d 77%,#e8b994 100%)}
.directions .direction-card.lamps:before{content:'';position:absolute;left:9%;top:11%;width:42%;height:78%;border-radius:50%;background-image:url('https://ravezox.github.io/kultura-neona/owl-real-card.webp');background-repeat:no-repeat;background-position:center 43%;background-size:165% auto;box-shadow:0 0 0 6px #f7dfc4,0 0 22px 10px #fff1c5,0 0 38px 18px #ffda88;-webkit-mask-image:none;mask-image:none;z-index:1}
.directions .direction-card.lamps:after{content:'';position:absolute;inset:0;pointer-events:none;z-index:0;background-image:url('https://ravezox.github.io/kultura-neona/owl-card.svg');background-size:100% 100%;background-position:center;opacity:.10}
.directions .direction-copy{position:absolute;top:11%;right:4%;width:43%;height:78%;display:flex;flex-direction:column;align-items:flex-start;z-index:2}
.directions .direction-card.lamps .direction-copy{right:4%;width:40%}
.directions .direction-copy h3{font-family:'Nunito',sans-serif!important;font-size:clamp(21px,2.2vw,32px)!important;line-height:1.08!important;letter-spacing:-.8px!important;font-weight:900!important;margin:0 0 8%}
.directions .direction-copy p{font-family:'Nunito Sans',sans-serif;font-size:clamp(12px,1.32vw,18px);line-height:1.3;font-weight:500;margin:0}
.directions .direction-copy .direction-link{margin-top:auto;flex:none;font-size:clamp(13px,1.2vw,17px);padding:11px 20px}
@media(max-width:760px){.directions .direction-card{min-height:235px;aspect-ratio:1.95/1}.directions .direction-copy h3{font-size:clamp(19px,4.6vw,29px)!important}.directions .direction-copy p{font-size:clamp(11px,3vw,16px)}.directions .direction-card.lamps:before{left:7%;width:44%}.directions .direction-card.neon{background-size:100% 100%,68% 100%}}
@media(max-width:390px){.directions .direction-copy h3{font-size:20px!important}.directions .direction-copy .direction-link{padding:9px 12px;font-size:12px}}

/* Pixel-oriented recreation of the approved NEON card only. */
.directions .direction-card.neon{background:#2b1b15;background-image:linear-gradient(90deg,transparent 0%,transparent 45%,#2b1b1599 51%,#2b1b15 58%),url('https://ravezox.github.io/kultura-neona/baby-barber-card.svg');background-size:100% 100%,54% 100%;background-repeat:no-repeat;background-position:center,left center}
.directions .direction-card.neon .direction-copy{top:10%;right:3.5%;width:43%;height:78%;display:flex;flex-direction:column;align-items:flex-start}
.directions .direction-card.neon .direction-copy h3{font-family:'Nunito',sans-serif!important;font-weight:900!important;font-size:clamp(22px,2.15vw,31px)!important;line-height:1.04!important;letter-spacing:-.9px!important;margin:0 0 7%;color:#fff}
.directions .direction-card.neon .direction-copy p{font-family:'Nunito Sans',sans-serif;font-weight:500;font-size:clamp(13px,1.34vw,18px);line-height:1.3;color:#fff;margin:0}
.directions .direction-card.neon .direction-copy .direction-link{margin-top:auto;background:#f36a0c;border:0;border-radius:999px;padding:11px 24px;font-family:'Nunito',sans-serif;font-weight:900;font-size:clamp(13px,1.27vw,18px);color:#fff}
@media(max-width:760px){.directions .direction-card.neon{background-size:100% 100%,54% 100%}.directions .direction-card.neon .direction-copy h3{font-size:clamp(20px,4.6vw,27px)!important}.directions .direction-card.neon .direction-copy p{font-size:clamp(11px,3vw,15px)}}
@media(max-width:390px){.directions .direction-card.neon .direction-copy h3{font-size:20px!important}.directions .direction-card.neon .direction-copy .direction-link{padding:9px 13px;font-size:12px}}

/* Exact approved neon artwork crop, with existing SVG as fallback until asset upload. */
.directions .direction-card.neon{background-color:#2b1b15;background-image:linear-gradient(90deg,transparent 0%,transparent 43%,#2b1b1580 49%,#2b1b15 56%),url('https://ravezox.github.io/kultura-neona/baby-barber-original-art.webp'),url('https://ravezox.github.io/kultura-neona/baby-barber-card.svg');background-size:100% 100%,53% 100%,53% 100%;background-position:center,left center,left center;background-repeat:no-repeat}
.directions .direction-card.neon .direction-copy{right:3.5%;width:43%;top:10%;height:78%}

/* Approved high-resolution Baby Barber artwork; fallback to previous asset until uploaded. */
.directions .direction-card.neon{background-image:linear-gradient(90deg,transparent 0%,transparent 43%,#2b1b1580 49%,#2b1b15 56%),url('https://ravezox.github.io/kultura-neona/baby-barber-hq.webp'),url('https://ravezox.github.io/kultura-neona/baby-barber-original-art.webp');background-size:100% 100%,53% 100%,53% 100%;background-position:center,left center,left center;background-repeat:no-repeat}

/* Approved reference: lamp card only. Real owl, reduced scale, text to the right. */
.directions .direction-card.lamps{
  background-image:url('https://ravezox.github.io/kultura-neona/lamp-card-trees.svg'),radial-gradient(ellipse at 29% 46%,#ffe7bd 0%,#f4d0a9 49%,#e7b995 100%);
  background-size:100% 100%,cover;
  background-position:center;
}
.directions .direction-card.lamps:before{
  content:'';position:absolute;left:10%;top:11%;width:40%;height:78%;
  aspect-ratio:auto;border-radius:50%;
  background-image:url('https://ravezox.github.io/kultura-neona/owl-real-card.webp');
  background-position:center center;
  background-size:100% auto;
  background-repeat:no-repeat;
  box-shadow:0 0 0 2px #f2d6b7,0 0 20px 6px #fff2ce,0 0 34px 12px #ffdc9c;
  z-index:1;mask-image:none;-webkit-mask-image:none;
}
.directions .direction-card.lamps:after{display:none}
.directions .direction-card.lamps .direction-copy{
  right:5%;top:12%;height:77%;width:39%;z-index:2;
}
.directions .direction-card.lamps .direction-copy h3{
  font-family:'Nunito',sans-serif!important;
  font-weight:900!important;font-size:clamp(22px,2.15vw,30px)!important;
  line-height:1.06!important;letter-spacing:-1.2px!important;margin:0 0 12px;
}
.directions .direction-card.lamps .direction-copy p{
  font-family:'Nunito Sans',sans-serif;font-weight:400;
  font-size:clamp(14px,1.35vw,18px);line-height:1.3;letter-spacing:0;
  margin:0 0 20px;
}
.directions .direction-card.lamps .direction-copy .direction-link{
  background:#e56423;border:0;border-radius:999px;
  padding:11px 23px;font-family:'Nunito',sans-serif;
  font-size:clamp(13px,1.27vw,18px);font-weight:900;
}
@media(max-width:760px){
  .directions .direction-card.lamps:before{left:8%;top:16%;width:41%;height:68%}
  .directions .direction-card.lamps .direction-copy h3{font-size:clamp(19px,4.6vw,26px)!important}
  .directions .direction-card.lamps .direction-copy p{font-size:clamp(11px,3vw,15px)}
}

/* Responsive hero only: reserved side columns keep images away from text.
   At 1920px display with 150% OS scaling, CSS viewport may be ~1280px. */
@media (min-width:761px) and (max-width:1400px){
  .hero{padding-left:28%;padding-right:28%}
  .hero .left-photo{left:0;width:min(23%,270px)}
  .hero .right-photo{right:0;width:min(24%,285px)}
}
@media (min-width:761px) and (max-width:950px){
  .hero{padding-left:27%;padding-right:27%}
  .hero .left-photo{left:0;width:23%}
  .hero .right-photo{right:0;width:24%}
  .hero h1{font-size:clamp(32px,4.2vw,42px)}
  .hero p{font-size:17px}
  .hero-actions{gap:7px}
  .hero-actions .cta{padding:10px 9px;font-size:11px}
}

/* Full-screen 1920x1080 laptop at Windows 125% (~1536 CSS px).
   Keep the central 44% text area clear while bringing both photos inward. */
@media (min-width:1401px) and (max-width:1650px){
  .hero .left-photo{left:0;width:307px}
  .hero .right-photo{right:0;width:328px}
}

/* Faithful scalable illustrated owl: no source photograph and no circular crop. */
.directions .direction-card.lamps:before{left:4%;top:0;width:51%;height:100%;aspect-ratio:auto;border-radius:0;background-image:url('https://ravezox.github.io/kultura-neona/owl-illustrated.svg');background-position:center;background-size:contain;box-shadow:none}
@media(max-width:760px){.directions .direction-card.lamps:before{left:2%;top:0;width:52%;height:100%}}

/* Owl card: image is decorative only; all words are selectable HTML. */
.directions .direction-card.lamps.owl-approved{
  background:#f5d5b6 url('https://ravezox.github.io/kultura-neona/owl-lamps-cropped.webp') center center/100% 100% no-repeat!important;
}
.directions .direction-card.lamps.owl-approved:before,
.directions .direction-card.lamps.owl-approved:after{display:none!important}
.directions .direction-card.lamps.owl-approved .direction-copy{
  position:absolute!important;inset:0 2% 0 auto!important;
  width:46%!important;height:100%!important;z-index:3!important;
  display:flex;flex-direction:column;align-items:flex-start;justify-content:center;
  padding:12px 8px 12px 0!important;text-align:left;pointer-events:none;
}
.directions .direction-card.lamps.owl-approved .direction-copy h3{
  visibility:visible!important;display:block;position:relative;
  font-family:'Nunito',sans-serif!important;font-weight:900!important;
  font-size:clamp(20px,2.1vw,30px)!important;line-height:1.05!important;
  letter-spacing:-1px!important;color:#2a1a12!important;
  margin:0 0 24px!important;
}
.directions .direction-card.lamps.owl-approved .direction-copy h3:after{
  content:'';position:absolute;left:20%;right:4%;bottom:-12px;height:4px;
  background:#ed641d;border-radius:60% 80% 70% 80%;transform:rotate(-2deg);
}
.directions .direction-card.lamps.owl-approved .direction-copy h3:before{
  content:'';position:absolute;right:-27px;top:-13px;width:30px;height:29px;
  background:linear-gradient(#f16a1c,#f16a1c) 4px 2px/4px 13px no-repeat,
  linear-gradient(#f16a1c,#f16a1c) 16px 0/4px 13px no-repeat,
  linear-gradient(#f16a1c,#f16a1c) 21px 18px/4px 12px no-repeat;
  transform:rotate(35deg);
}
.directions .direction-card.lamps.owl-approved .direction-copy p{
  visibility:visible!important;font-family:'Nunito Sans',sans-serif!important;
  font-weight:500!important;font-size:clamp(13px,1.27vw,17px)!important;
  line-height:1.32!important;letter-spacing:0!important;
  color:#342319!important;margin:0 0 17px!important;
}
.directions .direction-card.lamps.owl-approved .direction-copy .direction-link{
  position:relative!important;left:auto!important;top:auto!important;
  width:auto!important;height:auto!important;opacity:1!important;
  padding:10px 22px!important;margin:0!important;pointer-events:auto!important;
  border-radius:999px!important;background:#ed651f!important;
  color:white!important;font-family:'Nunito',sans-serif!important;
  font-size:15px!important;font-weight:900!important;
}
@media(max-width:760px){
  .directions .direction-card.lamps.owl-approved .direction-copy{width:46%!important;right:1%!important;padding-right:3px!important}
  .directions .direction-card.lamps.owl-approved .direction-copy h3{font-size:clamp(16px,4vw,23px)!important;margin-bottom:18px!important}
  .directions .direction-card.lamps.owl-approved .direction-copy h3:before{right:-15px;transform:rotate(35deg) scale(.7)}
  .directions .direction-card.lamps.owl-approved .direction-copy p{font-size:clamp(10px,2.7vw,14px)!important}
  .directions .direction-card.lamps.owl-approved .direction-copy .direction-link{font-size:12px!important;padding:8px 12px!important}
}

/* Final typography tuning, limited to the approved right-hand owl card. */
.directions .direction-card.lamps.owl-approved .direction-copy{
  justify-content:flex-start!important;top:10%!important;bottom:auto!important;
  height:80%!important;padding-top:0!important;padding-bottom:0!important;
}
.directions .direction-card.lamps.owl-approved .direction-copy h3{
  font-size:clamp(22px,2.15vw,31px)!important;
  line-height:1.04!important;letter-spacing:-.9px!important;
  margin:0 0 7%!important;
}
.directions .direction-card.lamps.owl-approved .direction-copy h3:before{display:none!important}
.directions .direction-card.lamps.owl-approved .direction-copy h3:after{
  left:20%!important;right:5%!important;bottom:-9px!important;height:4px!important;
  border-radius:55% 65% 75% 70%!important;transform:rotate(-2deg)!important;
}
.directions .direction-card.lamps.owl-approved .lamp-title-rays{
  position:absolute;width:36px;height:36px;right:-37px;top:-19px;overflow:visible;
}
.directions .direction-card.lamps.owl-approved .direction-copy p{
  font-size:clamp(13px,1.34vw,18px)!important;
  font-weight:400!important;line-height:1.3!important;
  margin:0!important;
}
.directions .direction-card.lamps.owl-approved .direction-copy .direction-link{
  margin-top:auto!important;
}
@media(max-width:760px){
  .directions .direction-card.lamps.owl-approved .direction-copy h3{font-size:clamp(18px,4.6vw,26px)!important}
  .directions .direction-card.lamps.owl-approved .direction-copy p{font-size:clamp(11px,3vw,15px)!important}
  .directions .direction-card.lamps.owl-approved .lamp-title-rays{width:24px;height:24px;right:-20px;top:-13px}
}

/* EXACT hero character accent geometry reused for owl heading. */
.directions .direction-card.lamps.owl-approved .direction-copy h3:after,
.directions .direction-card.lamps.owl-approved .direction-copy h3:before{content:none!important;display:none!important}
.directions .direction-card.lamps.owl-approved .lamp-accent{
  display:inline-block;position:relative;white-space:nowrap;
}
.directions .direction-card.lamps.owl-approved .lamp-underline{
  position:absolute;left:8%;bottom:-.20em;width:92%;height:.27em;
  color:#ed6019;overflow:visible;pointer-events:none;
}
.directions .direction-card.lamps.owl-approved .lamp-title-rays{
  position:absolute;left:calc(100% + .12em);top:-.18em;
  width:.75em;height:.79em;color:#ed6019;overflow:visible;pointer-events:none;
}

/* Cropped source image fills the same card bounds without shifting the top edge. */
.directions .direction-card.lamps.owl-approved{
  background-size:100% 100%!important;
  background-position:center center!important;
}

/* Portfolio carousel — next section from the approved prototype. */
.portfolio{max-width:1190px;margin:0 auto;padding:0 26px 28px}
.portfolio-head{display:flex;align-items:center;justify-content:space-between;gap:18px;margin:0 0 22px}
.portfolio-head h2{display:flex;align-items:center;gap:13px;font:900 clamp(25px,3vw,35px)/1.15 'Nunito',sans-serif;letter-spacing:-1.2px;margin:0}
.portfolio-head h2 svg{width:30px;height:34px;flex:none}
.portfolio-all{color:#dc5d1e;text-decoration:none;font:800 13px 'Nunito',sans-serif;border-bottom:1px solid #e57b45;padding-bottom:6px;white-space:nowrap}
.portfolio-carousel{display:flex;align-items:center;gap:9px}
.portfolio-track{display:flex;gap:8px;overflow-x:auto;scroll-snap-type:x mandatory;scrollbar-width:none;flex:1;min-width:0}
.portfolio-track::-webkit-scrollbar{display:none}
.portfolio-card{position:relative;flex:0 0 calc((100% - 32px)/5);aspect-ratio:1.68;min-width:0;display:flex;align-items:center;justify-content:center;overflow:hidden;border-radius:16px;scroll-snap-align:start;background:radial-gradient(ellipse at 50% 60%,#27252a,#0c0e15);text-align:center}
.portfolio-card:nth-child(2){background:radial-gradient(ellipse at 50% 50%,#39342f,#1c1a1b)}
.portfolio-card:nth-child(3){background:radial-gradient(ellipse at 50% 60%,#25271d,#101211)}
.portfolio-card:nth-child(4){background:radial-gradient(ellipse at 50% 55%,#39312b,#171514)}
.portfolio-card:nth-child(5){background:radial-gradient(ellipse at 50% 55%,#301a1a,#120d0d)}
.portfolio-neon{display:block;line-height:1.05;transform:rotate(-3deg);font-family:'Nunito',sans-serif;font-weight:800;letter-spacing:.015em}
.portfolio-neon.blue{font-size:clamp(15px,2.15vw,29px);color:#8aeaff;text-shadow:0 0 2px #fff,0 0 8px #00d8ff,0 0 19px #009cff}
.portfolio-neon.warm{font-size:clamp(19px,2.65vw,37px);font-family:cursive;font-style:italic;font-weight:400;color:#fff2df;text-shadow:0 0 3px #fff,0 0 10px #f8e0ae,0 0 19px #f5d4a5}
.portfolio-neon.green{font-size:clamp(37px,5vw,66px);color:#6ff7ab;text-shadow:0 0 4px #d4ffe4,0 0 11px #0be87c,0 0 22px #00b66a}
.portfolio-neon.red{font-size:clamp(20px,2.65vw,37px);font-weight:500;color:#ffb1a5;text-shadow:0 0 3px #fff,0 0 9px #ff4b31,0 0 19px #ef2010}
.portfolio-neon small{font-size:.43em;letter-spacing:.03em;display:block;margin-top:6px}
.portfolio-arrow{width:34px;height:34px;border-radius:50%;border:1px solid #e9c7ac;background:#fff8ef;color:#3c2d25;display:grid;place-items:center;flex:none;font-size:27px;line-height:1;padding:0}
.portfolio-arrow:hover{background:#fce9d7}
@media(max-width:760px){.portfolio{padding:0 16px 28px}.portfolio-head{align-items:flex-start}.portfolio-head h2{font-size:clamp(23px,5vw,29px)}.portfolio-all{font-size:11px}.portfolio-card{flex-basis:calc((100% - 8px)/2);aspect-ratio:1.55}.portfolio-neon.blue{font-size:22px}.portfolio-neon.warm{font-size:27px}.portfolio-neon.green{font-size:55px}.portfolio-neon.red{font-size:26px}.portfolio-arrow{width:29px;height:29px}}

/* Real workshop photographs in the existing portfolio carousel. */
.portfolio-card img{display:block;width:100%;height:100%;object-fit:contain;background:#0e0d0f}

/* Fill portfolio tiles more tightly, removing letterbox bands around photos. */
.portfolio .portfolio-card img{object-fit:cover!important;object-position:center!important;transform:scale(1.27);transform-origin:center}

/* Bespoke neon CTA, faithfully following the approved reference composition. */
.neon-cta{max-width:1190px;margin:0 auto;padding:0 26px 34px}
.neon-cta-panel{min-height:220px;border-radius:30px;position:relative;overflow:hidden;display:grid;grid-template-columns:25% 47% 28%;align-items:center;background:radial-gradient(ellipse at 70% 20%,#f7d4bc 0%,transparent 42%),linear-gradient(110deg,#f0c6a6 0%,#fff0e2 32%,#ffe6d2 72%,#efbc9a 100%);isolation:isolate}
.neon-cta-panel:after{content:"";position:absolute;inset:0;pointer-events:none;background:radial-gradient(ellipse at 45% 50%,#fff8ee80,transparent 65%);z-index:-1}
.neon-cta-notebook{position:relative;height:100%;min-height:220px;overflow:hidden}
.neon-cta-paper{position:absolute;width:180px;height:205px;left:13%;top:16px;transform:rotate(-9deg);background:#fff1df;box-shadow:3px 8px 12px #7b493f40;border-radius:4px 6px 9px 7px;padding:60px 16px 12px;color:#baa28d;font:italic 30px/1.2 cursive;text-align:center}
.neon-cta-paper:before{content:"";position:absolute;top:0;left:0;right:0;height:19px;background:repeating-linear-gradient(90deg,transparent 0 10px,#6b5848 10px 12px,transparent 12px 19px);border-bottom:2px solid #c6aa91}
.neon-cta-pen{position:absolute;width:160px;height:10px;background:linear-gradient(90deg,#302721 0 10%,#eee8df 11% 83%,#25201b 84% 100%);border-radius:8px;left:27%;bottom:34px;transform:rotate(-30deg);box-shadow:0 3px 3px #59403150}
.neon-cta-content{padding:22px 8px 22px 5px;position:relative;z-index:2}
.neon-cta-title{display:flex;align-items:center;gap:13px;margin:0 0 6px;font:900 clamp(27px,3vw,37px)/1.1 'Nunito',sans-serif;letter-spacing:-1px;color:#271d18;white-space:nowrap}
.neon-cta-title svg{width:48px;height:48px;flex:none;color:#e9611d}
.neon-cta-description{margin:0 0 18px 63px;font:500 clamp(13px,1.45vw,17px)/1.25 'Nunito Sans',sans-serif;color:#32251f}
.neon-cta-features{display:flex;align-items:center;justify-content:space-between;gap:12px;padding-left:6px}
.neon-cta-feature{display:flex;align-items:center;gap:8px;font:700 12px/1.2 'Nunito Sans',sans-serif;color:#31241e}
.neon-cta-feature svg{width:34px;height:34px;flex:none;color:#e9661d;stroke-width:1.8}
.neon-cta-side{height:100%;position:relative;display:flex;align-items:center;justify-content:center;padding:30px 14px}
.neon-cta-coils{position:absolute;right:-70px;top:-61px;width:330px;height:220px;transform:rotate(-13deg);opacity:1;pointer-events:none}

.neon-cta-button{position:relative;z-index:1;border:2px solid #fff;border-radius:999px;background:#e96824;color:white;padding:14px 22px;font:900 16px 'Nunito',sans-serif;white-space:nowrap;box-shadow:0 5px 16px #c05d2b30;cursor:pointer}
.neon-cta-button:hover{background:#d95917}
.neon-cta-arrow{position:absolute;bottom:9px;left:22%;width:90px;height:32px;color:#e96824}
.neon-request-dialog{border:0;border-radius:22px;padding:26px;width:min(440px,calc(100vw - 32px));box-shadow:0 20px 70px #27160b70;background:#fff7ed;color:#30231e}
.neon-request-dialog::backdrop{background:#20130bb3}
.neon-request-dialog h3{font:900 26px 'Nunito',sans-serif;margin:0 0 8px}
.neon-request-dialog p{font:500 14px/1.4 'Nunito Sans',sans-serif}
.neon-request-dialog label{display:block;font:800 13px 'Nunito',sans-serif;margin:12px 0 5px}
.neon-request-dialog textarea,.neon-request-dialog input{box-sizing:border-box;width:100%;border:1px solid #e8c5a8;border-radius:10px;background:#fff;padding:10px;font:500 14px 'Nunito Sans',sans-serif}
.neon-request-dialog textarea{min-height:90px;resize:vertical}
.neon-request-dialog .neon-request-actions{display:flex;gap:9px;margin-top:16px;align-items:center}
.neon-request-dialog button{border:0;border-radius:24px;padding:10px 16px;cursor:pointer;font:800 13px 'Nunito',sans-serif}
.neon-request-copy{background:#e96824;color:white}.neon-request-close{background:#eedfd2}
@media(max-width:900px){.neon-cta-panel{grid-template-columns:22% 52% 26%}.neon-cta-paper{left:-22%;transform:rotate(-9deg) scale(.9)}.neon-cta-pen{left:0}.neon-cta-title{font-size:27px}.neon-cta-title svg{width:36px}.neon-cta-description{margin-left:48px}.neon-cta-features{gap:6px}.neon-cta-feature{font-size:10px;gap:3px}.neon-cta-feature svg{width:25px}.neon-cta-button{font-size:13px;padding:11px 12px}}
@media(max-width:650px){.neon-cta{padding:0 16px 30px}.neon-cta-panel{grid-template-columns:1fr;min-height:0;padding:20px 18px 22px}.neon-cta-notebook{position:absolute;inset:0 auto auto 0;width:90px;height:110px;min-height:0;opacity:.2}.neon-cta-paper{top:-25px;left:-65px}.neon-cta-pen{display:none}.neon-cta-content{padding:5px 0}.neon-cta-title{font-size:clamp(24px,6vw,30px);white-space:normal;gap:5px}.neon-cta-title svg{width:30px;height:32px}.neon-cta-description{margin:6px 0 18px 34px;font-size:13px}.neon-cta-features{flex-wrap:wrap;gap:12px}.neon-cta-feature{font-size:11px}.neon-cta-feature svg{width:27px}.neon-cta-side{height:75px;padding:6px 0 0}.neon-cta-coils{width:180px;height:120px;right:-43px;top:-48px;opacity:.78}.neon-cta-arrow{display:none}.neon-cta-button{font-size:15px;padding:12px 25px}}

/* Approved photorealistic banner: activated only when the asset is uploaded. */
@media(min-width:651px){
.neon-cta-panel.neon-photo-ready{display:block;min-height:0;aspect-ratio:3 / 1;background:#f5d9c6 url('https://ravezox.github.io/kultura-neona/neon-banner-realistic.webp') center / 100% 100% no-repeat;border-radius:30px}
.neon-photo-ready .neon-cta-notebook,.neon-photo-ready .neon-cta-content,.neon-photo-ready .neon-cta-coils,.neon-photo-ready .neon-cta-arrow{display:none}
.neon-photo-ready .neon-cta-side{position:absolute;inset:0;display:block;padding:0}
.neon-photo-ready .neon-cta-button{position:absolute;left:33.5%;top:70%;width:31.5%;height:18%;border:0;border-radius:999px;background:transparent;color:transparent;box-shadow:none;font-size:0;cursor:pointer}
.neon-photo-ready .neon-cta-button:hover,.neon-photo-ready .neon-cta-button:focus-visible{background:#ffffff16;outline:2px solid #fff9;outline-offset:2px}
}

/* Banner: photographic background ONLY; copy, pictograms and button are editable HTML/SVG. */
.neon-cta-panel.neon-html-panel{display:flex;align-items:center;justify-content:center;min-height:0;aspect-ratio:3/1;background:#fae6d7 url('https://ravezox.github.io/kultura-neona/neon-banner-background.png') center/cover no-repeat;border-radius:30px}
.neon-html-panel:after{display:none}
.neon-html-content{width:51%;margin-left:2%;margin-right:0;text-align:center;position:relative;z-index:1;color:#321d17}
.neon-html-content h2{position:relative;display:inline-block;font:900 clamp(22px,3.1vw,41px)/1.05 'Nunito',sans-serif;letter-spacing:-1.3px;margin:0 0 9px;white-space:nowrap}
.neon-title-rays{position:absolute;top:-9px;right:-49px;width:44px;height:43px;color:#f36b13}
.neon-html-description{font:700 clamp(12px,1.55vw,20px)/1.23 'Nunito',sans-serif;margin:0 auto 17px}
.neon-html-benefits{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:0;margin-bottom:21px}
.neon-html-benefit{min-width:0;display:flex;align-items:center;flex-direction:column;gap:5px;font:800 clamp(10px,1.25vw,15px)/1.15 'Nunito',sans-serif}
.neon-html-benefit+ .neon-html-benefit{border-left:1px solid #e4a371}
.neon-html-benefit svg{width:43px;height:43px;color:#ee6816;flex:none}
.neon-html-button{display:inline-flex;align-items:center;justify-content:center;gap:15px;border:1px solid #ffb06e;background:linear-gradient(#ff7b00,#e85300);border-radius:100px;color:white;padding:12px 30px;box-shadow:0 5px 13px #b7471b40;font:900 clamp(15px,2vw,25px)/1.1 'Nunito',sans-serif;cursor:pointer;white-space:nowrap}
.neon-html-button svg{width:28px;height:28px;flex:none}
.neon-html-button:hover{filter:brightness(1.07);transform:translateY(-1px)}
.neon-html-button:focus-visible{outline:3px solid #432e24;outline-offset:3px}
@media(max-width:900px){.neon-html-content{width:58%;margin-left:0}.neon-html-benefit svg{width:30px;height:30px}.neon-html-description{margin-bottom:10px}.neon-html-benefits{margin-bottom:11px}.neon-html-button{padding:9px 16px;gap:8px}.neon-html-button svg{width:20px;height:20px}.neon-title-rays{right:-30px;width:28px}}
@media(max-width:650px){.neon-cta-panel.neon-html-panel{aspect-ratio:auto;min-height:300px;background-position:center;background-size:auto 100%;position:relative}.neon-cta-panel.neon-html-panel:before{content:"";position:absolute;inset:0;background:#fff1e5d9}.neon-html-content{width:100%;padding:25px 12px;margin:0}.neon-html-content h2{font-size:clamp(21px,6vw,28px);white-space:normal}.neon-html-description{font-size:13px;margin-bottom:17px}.neon-html-benefits{margin-bottom:19px}.neon-html-benefit{font-size:10px}.neon-html-benefit svg{width:31px;height:31px}.neon-html-button{font-size:16px;padding:12px 18px}.neon-title-rays{top:-12px;right:-22px}}

/* Workshop story section */
.workshop{max-width:1190px;margin:0 auto;padding:18px 26px 76px;position:relative}
.workshop-inner{display:grid;grid-template-columns:minmax(0,46%) minmax(0,1fr);align-items:stretch;gap:30px;position:relative;z-index:1}
.workshop-visual{height:auto;min-height:365px;border-radius:27px;overflow:hidden;position:relative;background:#30241e;box-shadow:0 12px 34px #3d281a1c}
.workshop-visual:before{content:"";position:absolute;inset:0;background:url('https://ravezox.github.io/kultura-neona/workshop-photo.webp') center/cover no-repeat}
.workshop-visual.workshop-photo-ready:before{background:url('https://ravezox.github.io/kultura-neona/workshop-photo.webp') center/cover no-repeat;opacity:1}
.workshop-visual-label{position:absolute;bottom:19px;left:20px;padding:9px 15px;background:#2a1b16b8;color:#fff1e2;border:1px solid #ffffff50;border-radius:999px;font:800 13px 'Nunito',sans-serif;letter-spacing:.2px}
.workshop-copy{position:relative;isolation:isolate;display:flex;flex-direction:column;justify-content:center;padding:26px 27px;border-radius:28px;background:linear-gradient(145deg,#fff8ef 0%,#f9ecdf 100%);border:1px solid #eedbc9;box-shadow:0 10px 35px #9e674a13;overflow:hidden}
.workshop-copy:before{content:"";position:absolute;right:-45px;top:-65px;width:230px;height:230px;border-radius:50%;background:radial-gradient(circle,#ffd9b77a 0%,#ffd9b700 72%);z-index:-1;pointer-events:none}
.workshop-copy:after{content:"";position:absolute;bottom:-8px;right:-5px;width:77%;height:88px;opacity:.21;background:#d6a17d;clip-path:polygon(0 100%,15% 50%,24% 71%,41% 9%,58% 79%,73% 35%,87% 76%,100% 43%,100% 100%);z-index:-1;pointer-events:none}
.workshop-copy h2{font:900 clamp(26px,2.8vw,36px)/1.13 'Nunito',sans-serif;letter-spacing:-1px;display:flex;align-items:center;gap:10px;margin:0 0 18px;color:#3b261d}
.workshop-rays{width:35px;height:36px;flex:none}
.workshop-copy p{font:750 15.5px/1.62 'Nunito Sans',sans-serif;margin:0 0 26px;max-width:570px;color:#584337}
.workshop-advantages{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:13px}
.workshop-advantage{display:flex;align-items:center;gap:12px;min-height:76px;padding:12px 11px;border-radius:16px;background:#ffffffbd;border:1px solid #f0dfcf;font:800 12px/1.32 'Nunito',sans-serif;color:#443027;box-shadow:0 3px 12px #b47c5110}
.workshop-advantage svg{width:44px;height:52px;flex:none;color:#e85c12}
.workshop-mountains{position:absolute;bottom:-5px;right:0;width:62%;height:110px;pointer-events:none;opacity:.19}
@media(max-width:900px){.workshop-inner{gap:18px;grid-template-columns:minmax(0,44%) minmax(0,1fr)}.workshop-copy{padding:24px 19px}.workshop-advantage{font-size:11px;padding:9px 8px}.workshop-advantage svg{width:36px;height:44px}}
@media(max-width:760px){.workshop{padding:12px 16px 54px}.workshop-inner{grid-template-columns:1fr;gap:22px}.workshop-visual{height:285px;min-height:0}.workshop-copy{padding:25px 19px 31px}.workshop-copy h2{font-size:29px}.workshop-copy p{font-size:14px}.workshop-advantages{gap:10px}.workshop-advantage{font-size:12px}.workshop-mountains{width:100%}}
@media(max-width:390px){.workshop-advantages{grid-template-columns:1fr}.workshop-advantage{min-height:55px}}
</style><?php wp_head(); ?></head><body><svg xmlns="http://www.w3.org/2000/svg" width="0" height="0" style="position:absolute;overflow:hidden" aria-hidden="true"><defs>
<clipPath id="coffee-blob" clipPathUnits="objectBoundingBox"><path d="M 0,0.005 C .19,.008 .38,.018 .56,.022 C .76,.024 .89,.08 .956,.205 C 1.01,.315 1.005,.52 .949,.648 C .893,.781 .769,.873 .601,.917 C .42,.97 .284,1.02 .127,.992 C .073,.985 .029,.969 0,.95 Z"/></clipPath>
<clipPath id="lion-blob" clipPathUnits="objectBoundingBox"><path d="M 1,.02 C .89,.018 .81,.055 .73,.09 C .61,.145 .52,.085 .40,.075 C .26,.055 .16,.115 .135,.245 C .105,.375 .165,.445 .10,.545 C .015,.655 .015,.715 .075,.80 C .16,.92 .32,1 .47,.995 C .64,.99 .76,.90 .88,.915 C .93,.92 .97,.925 1,.93 Z"/></clipPath>
</defs></svg><header class="site-header"><div class="logo"><span class="logo-mark"><i></i><i></i><i></i></span>КУЛЬТУРА НЕОНА</div><nav id="nav"><a class="active" href="#home">Главная</a><a href="#order" data-toast="Каталог неоновых вывесок добавим следующим блоком">Неон на заказ</a><a href="#lamps" data-toast="Каталог светильников добавим следующим блоком">Светильники</a><a href="#portfolio" data-toast="Портфолио добавим следующим блоком">Портфолио</a><a href="#about">О мастерской</a><a href="#contacts" data-toast="Контакты добавим позже">Контакты</a></nav><div class="header-icons"><button class="icon-btn" aria-label="Поиск" data-toast="Поиск подключим с каталогом"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="10.5" cy="10.5" r="7.5"/><path d="m16 16 6 6"/></svg></button><button class="icon-btn account" aria-label="Личный кабинет" data-toast="Личный кабинет пока не подключён"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="7" r="4"/><path d="M4 22v-3a8 8 0 0 1 16 0v3"/></svg></button><button class="icon-btn" aria-label="Корзина" data-toast="Корзина появится вместе с каталогом"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M2 3h3l3 13h12l2-10H6"/><circle cx="9" cy="21" r="1"/><circle cx="19" cy="21" r="1"/></svg><span class="cart-count">0</span></button><button class="icon-btn mobile-menu" id="menuButton" aria-label="Открыть меню" aria-expanded="false"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 6h18M3 12h18M3 18h18"/></svg></button></div></header><main id="home"><section class="hero" aria-label="Главный экран"><div class="left-photo" role="img" aria-label="Неоновая вывеска Кофе с собой в интерьере"></div><div class="right-photo" role="img" aria-label="Деревянный светильник львёнок в детской комнате"></div><span class="spark one" aria-hidden="true">⌁</span><div class="eyebrow">ТВОРЧЕСКАЯ МАСТЕРСКАЯ СВЕТА</div><h1>Свет, у которого<br>есть <span class="character-accent">характер<svg class="character-underline" viewBox="0 0 260 24" preserveAspectRatio="none" aria-hidden="true"><path d="M5 19 Q132 -1 255 17" fill="none" stroke="currentColor" stroke-width="7" stroke-linecap="round"/></svg></span><span class="character-period"><span class="character-period-text">.</span><svg class="character-rays" viewBox="0 0 54 54" aria-hidden="true"><path d="M9 23 L14 5 M18 33 L34 18 M24 46 L47 42" fill="none" stroke="currentColor" stroke-width="4.5" stroke-linecap="round"/></svg></span></h1><p>Неоновые вывески на заказ.<br>Авторские светильники.</p><div class="hero-actions"><a class="cta primary" href="#order" data-toast="Форму заказа неона добавим следующим этапом"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="m13 2-9 11h7l-1 9 10-13h-7l1-7z"/></svg>Заказать неон <span>›</span></a><a class="cta secondary" href="#lamps" data-toast="Каталог светильников добавим следующим этапом"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M7 16h10l3-8H4l3 8zM12 16v5M8 21h8M9 8V5a3 3 0 0 1 6 0v3"/></svg>Смотреть светильники <span>›</span></a></div><div class="benefits"><div class="benefit"><svg viewBox="0 0 40 40"><path d="M8 32C4 12 20 8 33 6c-1 14-6 28-25 26ZM8 32c7-8 13-12 21-18"/></svg><span>Собственное<br>производство</span></div><div class="benefit"><svg viewBox="0 0 40 40"><circle cx="10" cy="12" r="6"/><circle cx="10" cy="12" r="2"/><circle cx="24" cy="12" r="6"/><circle cx="24" cy="12" r="2"/><circle cx="17" cy="26" r="6"/><circle cx="17" cy="26" r="2"/><path d="M29 23h8v9h-8zM5 34h27"/></svg><span>Натуральные<br>материалы</span></div><div class="benefit"><svg viewBox="0 0 40 40"><path d="M20 34 6 21C-2 11 9 2 20 14 31 2 42 11 34 21Z"/></svg><span>Сделано<br>в России</span></div></div><div class="ornament left"></div><div class="ornament right"></div><svg class="hero-wave left" viewBox="0 0 340 95" preserveAspectRatio="none" aria-hidden="true"><path d="M -8 12 C 52 49 95 34 145 18 C 205 -2 238 11 272 43 C 296 67 310 82 340 91"/></svg><svg class="hero-wave right" viewBox="0 0 340 95" preserveAspectRatio="none" aria-hidden="true"><path d="M -5 90 C 65 85 95 60 148 38 C 213 10 273 12 345 24"/></svg></section><section class="directions" id="directions" aria-labelledby="directions-title"><h2 id="directions-title"><svg class="directions-sparks" viewBox="0 0 45 45" aria-hidden="true"><path d="M 7 9 L 23 19 M 27 4 L 35 16 M 4 30 L 22 31" fill="none" stroke="#e9621b" stroke-width="4.5" stroke-linecap="round"/></svg><span>Наши направления</span></h2><div class="directions-grid"><article class="direction-card neon"><div class="direction-copy"><h3>Неоновые<br>вывески на заказ</h3><p>Для бизнеса, интерьера,<br>мероприятий и подарков</p><button type="button" class="direction-link" data-direction="neon" aria-haspopup="dialog">Подробнее <span>›</span></button></div></article><article class="direction-card lamps owl-approved"><div class="direction-copy"><h3>Авторские<br><span class="lamp-accent">светильники<svg class="lamp-underline" viewBox="0 0 260 24" preserveAspectRatio="none" aria-hidden="true"><path d="M5 19 Q132 -1 255 17" fill="none" stroke="currentColor" stroke-width="7" stroke-linecap="round"/></svg><svg class="lamp-title-rays" viewBox="0 0 54 54" aria-hidden="true"><path d="M9 23 L14 5 M18 33 L34 18 M24 46 L47 42" fill="none" stroke="currentColor" stroke-width="4.5" stroke-linecap="round"/></svg></span></h3><p>Детские ночники<br>и дизайнерские модели<br>для дома</p><a class="direction-link" href="<?php echo esc_url( home_url( '/svetilniki/' ) ); ?>">В каталог <span>›</span></a></div></article></div></section><section class="portfolio" id="portfolio" aria-labelledby="portfolio-title"><div class="portfolio-head"><h2 id="portfolio-title"><svg viewBox="0 0 40 40" aria-hidden="true"><path d="M7 7 L21 18 M29 2 L31 16 M3 27 L18 28" stroke="#e86620" stroke-width="4" stroke-linecap="round" fill="none"/></svg>Примеры наших работ</h2><a class="portfolio-all" href="#portfolio" data-toast="Полное портфолио скоро появится">Смотреть всё портфолио ›</a></div><div class="portfolio-carousel"><button class="portfolio-arrow" type="button" data-portfolio-move="-1" aria-label="Предыдущие работы">‹</button><div class="portfolio-track" id="portfolio-track" aria-label="Галерея примеров неоновых вывесок"><div class="portfolio-card" aria-label="Неоновая вывеска НЕВОД с голубым знаком и жёлтой надписью"><img src="https://ravezox.github.io/kultura-neona/portfolio-01.webp" alt="Неоновая вывеска НЕВОД с голубым знаком и жёлтой надписью" loading="lazy" decoding="async"></div><div class="portfolio-card" aria-label="Вывеска программирование от робототехника 5 лет"><img src="https://ravezox.github.io/kultura-neona/portfolio-02.webp" alt="Вывеска программирование от робототехника 5 лет" loading="lazy" decoding="async"></div><div class="portfolio-card" aria-label="Неоновая вывеска WARHAMMER — сборные модели, краски"><img src="https://ravezox.github.io/kultura-neona/portfolio-03.webp" alt="Неоновая вывеска WARHAMMER — сборные модели, краски" loading="lazy" decoding="async"></div><div class="portfolio-card" aria-label="Белая неоновая вывеска такая сильная любовь"><img src="https://ravezox.github.io/kultura-neona/portfolio-04.webp" alt="Белая неоновая вывеска такая сильная любовь" loading="lazy" decoding="async"></div><div class="portfolio-card" aria-label="Тёплая неоновая надпись Вместе навсегда"><img src="https://ravezox.github.io/kultura-neona/portfolio-05.webp" alt="Тёплая неоновая надпись Вместе навсегда" loading="lazy" decoding="async"></div><div class="portfolio-card" aria-label="Красная неоновая вывеска в форме силуэта"><img src="https://ravezox.github.io/kultura-neona/portfolio-06.webp" alt="Красная неоновая вывеска в форме силуэта" loading="lazy" decoding="async"></div><div class="portfolio-card" aria-label="Новогодняя разноцветная неоновая ёлочка"><img src="https://ravezox.github.io/kultura-neona/portfolio-07.webp" alt="Новогодняя разноцветная неоновая ёлочка" loading="lazy" decoding="async"></div><div class="portfolio-card" aria-label="Красная неоновая вывеска Вкусный чай"><img src="https://ravezox.github.io/kultura-neona/portfolio-08.webp" alt="Красная неоновая вывеска Вкусный чай" loading="lazy" decoding="async"></div></div><button class="portfolio-arrow" type="button" data-portfolio-move="1" aria-label="Следующие работы">›</button></div></section><section class="neon-cta" id="custom-neon" aria-labelledby="neon-cta-title"><div class="neon-cta-panel neon-html-panel"><div class="neon-html-content"><h2 id="neon-cta-title">Создадим ваш неон!<svg class="neon-title-rays" viewBox="0 0 50 42" aria-hidden="true"><path d="M10 13L18 3M20 22L36 14M20 33L39 36" fill="none" stroke="currentColor" stroke-width="5" stroke-linecap="round"/></svg></h2><p class="neon-html-description">Неоновая вывеска по вашей идее:<br>для бизнеса, интерьера и особых событий.</p><div class="neon-html-benefits"><div class="neon-html-benefit"><svg viewBox="0 0 48 48" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linejoin="round" stroke-linecap="round"><path d="M7 13L13 7L41 35L35 41Z M28 7L41 20 M7 28L20 41 M13 7L7 13 M28 7L41 20 M7 28L20 41"/><path d="M17 11L12 16M22 16L17 21M27 21L22 26M32 26L27 31"/></svg><span>Индивидуальный<br>дизайн</span></div><div class="neon-html-benefit"><svg viewBox="0 0 48 48" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"><path d="M19 4H29L31 10L37 13L43 10L47 19L42 24L43 30L47 35L41 43L35 39L29 42L27 47H19L17 41L11 38L5 42L1 33L6 28L5 20L1 15L7 7L13 11L19 9Z" transform="translate(2 2) scale(.88)"/><circle cx="24" cy="24" r="9"/></svg><span>Собственное<br>производство</span></div><div class="neon-html-benefit"><svg viewBox="0 0 48 48" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M27 3L11 26H23L19 45L39 19H26Z"/></svg><span>Яркий, надёжный<br>и долговечный</span></div></div><button type="button" class="neon-html-button" id="neon-request-open"><svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="3" width="22" height="26" rx="3"/><path d="M9 9H23V14H9Z M10 19H12M16 19H18M22 19H23M10 24H12M16 24H18M22 24H23"/></svg><span>Рассчитать заказ</span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" aria-hidden="true"><path d="M3 12H21M14 5L21 12L14 19"/></svg></button></div></div></section><section class="workshop" id="about" aria-labelledby="workshop-title"><div class="workshop-inner"><div class="workshop-visual" role="img" aria-label="Неоновая вывеска ручной работы в мастерской"><span class="workshop-visual-label">Культура Неона · собственное производство</span></div><div class="workshop-copy"><h2 id="workshop-title"><svg class="workshop-rays" viewBox="0 0 42 42" aria-hidden="true"><path d="M8 8L21 21M29 3L31 18M3 29L18 30" fill="none" stroke="#e86620" stroke-width="4" stroke-linecap="round"/></svg>О нашей мастерской</h2><p>«Культура Неона» — это собственное производство, где мы создаём неоновые вывески и авторские светильники с вниманием к деталям и любовью к своему делу.</p><div class="workshop-advantages">
<div class="workshop-advantage"><svg viewBox="0 0 56 64" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 49L32 26L38 32L15 55Q12 58 9 55Q6 52 9 49Z"/><path d="M32 26L37 21L43 27L38 32Z"/><path d="M40 24L49 15L52 12"/><path d="M17 56C13 62 21 63 26 59C31 55 35 56 38 60"/><path d="M44 7L44 12M36 10L39 14M50 18L54 20"/></svg><span>Ручная сборка</span></div>
<div class="workshop-advantage"><svg viewBox="0 0 56 64" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M28 5C21 11 13 14 7 16V33C7 45 15 53 28 60C41 53 49 45 49 33V16C40 13 34 10 28 5Z"/><path d="M18 32L25 39L39 24"/></svg><span>Надёжные и безопасные<br>материалы</span></div>
<div class="workshop-advantage"><svg viewBox="0 0 56 64" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M34 4L9 34H26L19 60L48 25H30L34 4Z"/></svg><span>Современные технологии</span></div>
<div class="workshop-advantage"><svg viewBox="0 0 56 64" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M28 60C28 60 7 37 7 25C7 13 16 4 28 4S49 13 49 25C49 37 28 60 28 60Z"/><circle cx="28" cy="25" r="9"/></svg><span>Производство в Сибири<br>(г. Барнаул)</span></div></div></div></div><svg class="workshop-mountains" viewBox="0 0 700 120" preserveAspectRatio="none" aria-hidden="true"><path d="M0 118L105 60L160 87L270 18L385 105L505 42L610 105L700 66V120Z" fill="#e6c8ac"/><path d="M0 120L140 95L240 120L340 70L430 120L565 78L700 120Z" fill="#d3b49b"/></svg></section><script>(function(){const img=new Image();img.onload=()=>document.querySelector('.workshop-visual')?.classList.add('workshop-photo-ready');img.src='https://ravezox.github.io/kultura-neona/workshop-photo.webp'})();</script><dialog id="neon-request-dialog" class="neon-request-dialog" aria-labelledby="neon-request-title"><h3 id="neon-request-title">Рассчитать неоновую вывеску</h3><p>Опиши свою идею и примерный размер. Подготовим текст заявки, который можно скопировать и отправить мастерской.</p><label for="neon-request-idea">Что хочешь изготовить?</label><textarea id="neon-request-idea" placeholder="Надпись, логотип, форма, цвет..."></textarea><label for="neon-request-size">Примерные размеры</label><input id="neon-request-size" placeholder="Например, 55 × 40 см"><div class="neon-request-actions"><button type="button" class="neon-request-copy" id="neon-request-copy">Скопировать заявку</button><button type="button" class="neon-request-close" id="neon-request-close">Закрыть</button></div><p id="neon-request-status" role="status"></p></dialog><dialog class="direction-dialog" id="direction-dialog" aria-labelledby="direction-dialog-title"><div class="direction-dialog-inner"><button type="button" class="direction-dialog-close" aria-label="Закрыть">×</button><h3 id="direction-dialog-title"></h3><img id="direction-dialog-image" alt=""><p id="direction-dialog-description"></p></div></dialog></main><div id="notice" class="notice" role="status"></div><script>const notice=document.getElementById('notice');let timeout;document.querySelectorAll('[data-toast]').forEach(el=>el.addEventListener('click',e=>{e.preventDefault();notice.textContent=el.dataset.toast;notice.classList.add('show');clearTimeout(timeout);timeout=setTimeout(()=>notice.classList.remove('show'),3300)}));document.getElementById('menuButton').addEventListener('click',()=>{let nav=document.getElementById('nav');let open=nav.classList.toggle('open');document.getElementById('menuButton').setAttribute('aria-expanded',open)})
const directionDialog=document.getElementById('direction-dialog');
const directionInfo={neon:{title:'Неоновые вывески на заказ',image:'baby-barber-card.svg',alt:'Неоновая вывеска Baby Barber с короной и ножницами',description:'Создаём неоновые вывески для бизнеса, интерьера, мероприятий и подарков. Дизайн и размеры подбираются под вашу идею.'},lamps:{title:'Авторские светильники',image:'owl-real-card.webp',alt:'Настоящий деревянный ночник-сова с тёплой подсветкой',description:'Деревянные светильники и детские ночники собственного производства. На фото — наша сова с мягким тёплым светом.'}};
document.querySelectorAll('.directions [data-direction]').forEach(button=>button.addEventListener('click',()=>{const data=directionInfo[button.dataset.direction];document.getElementById('direction-dialog-title').textContent=data.title;const pic=document.getElementById('direction-dialog-image');pic.src=data.image;pic.alt=data.alt;document.getElementById('direction-dialog-description').textContent=data.description;directionDialog.showModal()}));
document.querySelector('.direction-dialog-close').addEventListener('click',()=>directionDialog.close());
directionDialog.addEventListener('click',event=>{if(event.target===directionDialog)directionDialog.close()});
document.querySelectorAll('[data-portfolio-move]').forEach(button=>button.addEventListener('click',()=>{const track=document.getElementById('portfolio-track');const card=track.querySelector('.portfolio-card');track.scrollBy({left:Number(button.dataset.portfolioMove)*(card.getBoundingClientRect().width+8),behavior:'smooth'});}));
</script><script>
/* Activate approved card only if its high-quality file exists in the repository. */
(function(){
  const owl = new Image();
  owl.onload = function(){ document.querySelector('.direction-card.lamps')?.classList.add('owl-approved'); };
  owl.src = 'owl-lamps-cropped.webp';
})();
</script>
<script>
(function(){
 const dialog=document.getElementById('neon-request-dialog');
 document.getElementById('neon-request-open').addEventListener('click',()=>dialog.showModal());
 document.getElementById('neon-request-close').addEventListener('click',()=>dialog.close());
 dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close()});
 document.getElementById('neon-request-copy').addEventListener('click',async()=>{
  const idea=document.getElementById('neon-request-idea').value.trim();
  const size=document.getElementById('neon-request-size').value.trim();
  const status=document.getElementById('neon-request-status');
  if(!idea){status.textContent='Напиши хотя бы кратко, какая вывеска нужна.';return}
  const message='Здравствуйте! Хочу рассчитать неоновую вывеску.\\nИдея: '+idea+'\\nРазмеры: '+(size||'Нужно подобрать');
  try{await navigator.clipboard.writeText(message);status.textContent='Заявка скопирована. Теперь её можно отправить мастерской.'}
  catch(e){status.textContent='Не удалось скопировать автоматически. Выдели текст и скопируй вручную.'}
 });
})();
</script><?php wp_footer(); ?></body></html>